import re
import datetime as dt
import psycopg2
from psycopg2.extras import RealDictCursor

# =========================
# CONEXÕES (variáveis locais)
# =========================
PROD = dict(host="10.50.13.33", port=5432, dbname="dw", user="mrfamos", password="SENHA_PROD")
HML  = dict(host="127.0.0.1", port=5432, dbname="dw_hml", user="postgres", password="SENHA_HML")

SCHEMA = "public"

# =========================
# MODELO CONFIG
# =========================
CONFIG_TEXT = """
Tabela_Pai|Campo_Fitro|Dias_Filtro|Tabelas_Filha
cbcontrato|data_ultima_distrib_dat|90|cbparcela
cbbordero|data_dat|90|cbitembordero->cbparcelaitembordero
cbfollwup|data_dat|90|
""".strip()

# Detecta colunas do tipo: id_cbsituacaocontrato_int -> tabela ref: cbsituacaocontrato
REF_COL_RE = re.compile(r"^id_([a-z0-9_]+)_int$", re.IGNORECASE)

# Opcional: blacklist para evitar tentar “resolver” tabelas que não existem ou não são referência
REF_TABLE_BLACKLIST = {
    # ex.: "cbcontrato",  # se houver colunas que parecem referência mas não são
}

# =========================
# HELPERS
# =========================
def conn_str(cfg: dict) -> str:
    return f"host={cfg['host']} port={cfg['port']} dbname={cfg['dbname']} user={cfg['user']} password={cfg['password']}"

def qname(table: str) -> str:
    return f"{SCHEMA}.{table}"

def pk_of(table: str) -> str:
    return f"id_{table}_int"

def parse_config(text: str):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    header = lines[0].split("|")
    if header != ["Tabela_Pai", "Campo_Fitro", "Dias_Filtro", "Tabelas_Filha"]:
        raise ValueError(f"Header inesperado no CONFIG. Recebido: {header}")

    items = []
    for l in lines[1:]:
        parts = [p.strip() for p in l.split("|")]
        if len(parts) != 4:
            raise ValueError(f"Linha inválida: {l}")
        tabela_pai, campo_filtro, dias, filhas = parts
        items.append({
            "tabela_pai": tabela_pai,
            "campo_filtro": campo_filtro,
            "dias": int(dias),
            "filhas_chain": [x.strip() for x in filhas.split("->")] if filhas else []
        })
    return items

def table_exists(prod_cur, table: str) -> bool:
    prod_cur.execute("SELECT to_regclass(%s)", (qname(table),))
    return prod_cur.fetchone()[0] is not None

def get_table_columns(prod_cur, table: str) -> list[str]:
    sql = """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s
        ORDER BY ordinal_position
    """
    prod_cur.execute(sql, (SCHEMA, table))
    return [r[0] for r in prod_cur.fetchall()]

def build_insert_sql(table: str, columns: list[str]) -> str:
    cols_csv = ", ".join(columns)
    vals_csv = ", ".join([f"%({c})s" for c in columns])
    pk = pk_of(table)
    return f"""
        INSERT INTO {qname(table)} ({cols_csv})
        VALUES ({vals_csv})
        ON CONFLICT ({pk}) DO NOTHING
    """

def fetch_rows_by_filter(prod_cur, table: str, date_col: str, days: int):
    cutoff = dt.date.today() - dt.timedelta(days=days)
    sql = f"SELECT * FROM {qname(table)} WHERE {date_col} >= %s"
    prod_cur.execute(sql, (cutoff,))
    return prod_cur.fetchall()

def fetch_rows_by_fk(prod_cur, child_table: str, parent_table: str, parent_id_value):
    fk = f"id_{parent_table}_int"
    sql = f"SELECT * FROM {qname(child_table)} WHERE {fk} = %s"
    prod_cur.execute(sql, (parent_id_value,))
    return prod_cur.fetchall()

def fetch_one_by_pk(prod_cur, table: str, pk_value):
    pk = pk_of(table)
    sql = f"SELECT * FROM {qname(table)} WHERE {pk} = %s"
    prod_cur.execute(sql, (pk_value,))
    return prod_cur.fetchone()

def ensure_dest_table_exists(hml_cur, table: str):
    hml_cur.execute("SELECT to_regclass(%s)", (qname(table),))
    if hml_cur.fetchone()[0] is None:
        raise RuntimeError(f"Tabela destino não existe: {qname(table)}. Rode schema primeiro.")

# =========================
# NÚCLEO: inserção recursiva por dependências
# =========================
def find_reference_tables(prod_cur, table: str, cols_cache: dict[str, list[str]]):
    """
    Retorna lista de (coluna, ref_table) detectadas por id_<ref>_int
    """
    if table not in cols_cache:
        cols_cache[table] = get_table_columns(prod_cur, table)

    refs = []
    for col in cols_cache[table]:
        m = REF_COL_RE.match(col)
        if not m:
            continue
        ref_table = m.group(1).lower()

        # ignora PK da própria tabela (id_<tabela>_int)
        if ref_table == table.lower():
            continue

        if ref_table in REF_TABLE_BLACKLIST:
            continue

        # se a tabela ref não existir, ignora (ou você pode preferir falhar)
        if table_exists(prod_cur, ref_table):
            refs.append((col, ref_table))
    return refs

def insert_row_with_deps(prod_cur, hml_cur, table: str, row: dict,
                         inserted_cache: set[tuple[str, int]],
                         cols_cache: dict[str, list[str]]):
    """
    Antes de inserir (table,row), resolve todos os id_<ref>_int presentes na row.
    Depois insere a row (1 a 1).
    """
    pk = pk_of(table)
    if pk not in row:
        raise RuntimeError(f"PK {pk} não encontrada na linha de {table}. Ajuste convenção/mapeamento.")

    pk_val = row.get(pk)
    if pk_val is None:
        return

    cache_key = (table, int(pk_val))
    if cache_key in inserted_cache:
        return

    # 1) resolve referências detectadas por nome de coluna
    refs = find_reference_tables(prod_cur, table, cols_cache)
    for col_name, ref_table in refs:
        ref_id = row.get(col_name)
        if ref_id is None:
            continue

        ref_pk = pk_of(ref_table)
        ref_row = fetch_one_by_pk(prod_cur, ref_table, ref_id)
        if ref_row is None:
            # referência aponta para algo que não existe (ambiente sujo)
            # aqui eu prefiro só pular; se quiser travar, lance erro.
            continue

        # recursão: resolve deps da referência antes de inserir ela
        insert_row_with_deps(prod_cur, hml_cur, ref_table, ref_row, inserted_cache, cols_cache)

    # 2) garante tabela destino existe
    ensure_dest_table_exists(hml_cur, table)

    # 3) insere a row atual
    cols = list(row.keys())
    ins_sql = build_insert_sql(table, cols)
    hml_cur.execute(ins_sql, row)

    inserted_cache.add(cache_key)

def replicate_chain(prod_cur, hml_cur, parent_table: str, parent_rows: list[dict],
                    chain: list[str], inserted_cache, cols_cache):
    """
    Cadeia: child1 -> child2 -> ...
    Busca filhos por id_<parent>_int em cada nível.
    """
    current_parent_table = parent_table
    current_parent_rows = parent_rows

    for child_table in chain:
        next_level_rows = []
        parent_pk = pk_of(current_parent_table)

        for pr in current_parent_rows:
            pid = pr.get(parent_pk)
            if pid is None:
                continue
            child_rows = fetch_rows_by_fk(prod_cur, child_table, current_parent_table, pid)
            for cr in child_rows:
                insert_row_with_deps(prod_cur, hml_cur, child_table, cr, inserted_cache, cols_cache)
            next_level_rows.extend(child_rows)

        current_parent_table = child_table
        current_parent_rows = next_level_rows

# =========================
# MAIN
# =========================
def main():
    config_items = parse_config(CONFIG_TEXT)

    with psycopg2.connect(conn_str(PROD)) as prod_conn, psycopg2.connect(conn_str(HML)) as hml_conn:
        prod_conn.autocommit = False
        hml_conn.autocommit = False

        inserted_cache: set[tuple[str, int]] = set()
        cols_cache: dict[str, list[str]] = {}

        with prod_conn.cursor(cursor_factory=RealDictCursor) as prod_cur, hml_conn.cursor() as hml_cur:
            for item in config_items:
                pai = item["tabela_pai"]
                campo = item["campo_filtro"]
                dias = item["dias"]
                chain = item["filhas_chain"]

                print(f"\n==> {pai} | {campo} | {dias} dias | chain: {'->'.join(chain) if chain else '-'}")

                # 1) select pai
                parent_rows = fetch_rows_by_filter(prod_cur, pai, campo, dias)
                print(f"   pais encontrados: {len(parent_rows)}")

                # 2) inserir 1 a 1, garantindo deps por colunas id_*_int
                for pr in parent_rows:
                    insert_row_with_deps(prod_cur, hml_cur, pai, pr, inserted_cache, cols_cache)

                # 3) filhas em cadeia
                if chain:
                    replicate_chain(prod_cur, hml_cur, pai, parent_rows, chain, inserted_cache, cols_cache)

                hml_conn.commit()

    print("\nConcluído ✅")

if __name__ == "__main__":
    main()
